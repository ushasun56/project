package com.yash.dao;
/**
 * seperated interface is created for the method of jdbc to showing all record;
 * @author usha.more
 *
 */

public interface EmployeeInterface 
{
   public void showEmployeeList() throws Exception;
}
